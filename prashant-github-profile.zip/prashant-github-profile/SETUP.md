# How to publish Prashant's GitHub profile

This package includes a complete `README.md` and three original, self-contained SVG graphics. **No repository has been created and nothing has been pushed.**

## Set it up in Prashant's account

1. Sign in at GitHub **using Prashant's own account**.
2. Create a **public** repository with the **exact same name as his GitHub username**. For example, a user called `prashant-dev` needs a repository named `prashant-dev`.
3. Upload `README.md` and the entire `assets/` folder into the **root** of that repository. Keep the filenames and relative paths unchanged.
4. Commit the files to the repository's default branch. Visit `https://github.com/USERNAME` (replace `USERNAME` with his actual username) to see the live profile.
5. Pin Prashant's real repositories on his profile using GitHub's "Customize your pins" feature.

## Personalize if you want

- The profile intentionally does **not** list unverified technical skills, fake projects, employer titles, stats, or social accounts.
- The bio text is a starting point: update it to match Prashant's real interests and preferred voice.
- Want different wording? Edit `README.md`. Need a different accent color or tagline? Edit the original SVG files in `assets/`.
- Markdown and local SVG assets render directly in GitHub; no build step, workflow, or external image service is needed.

## Included files

- `README.md` — GitHub-ready profile
- `assets/hero.svg` — custom dark architectural hero
- `assets/rule.svg` — subtle divider
- `assets/signoff.svg` — custom ending graphic
- `profile-preview.png` — visual preview of the hero and ending graphic (not needed for publishing)

Built as a personal profile for Prashant, team member at KITTY CORP. Company: https://kittycorp.vercel.app/
