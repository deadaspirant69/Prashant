<p align="center">
  <img src="./assets/hero.svg" alt="Prashant — building, learning and creating as a member of the KITTY CORP team" width="100%" />
</p>

<p align="center">
  <strong>Make it useful. Make it better.</strong>
</p>

<p align="center">
  <a href="https://kittycorp.vercel.app/">KITTY CORP</a> &nbsp;·&nbsp; Team Member
</p>

<p align="center">
  <img src="./assets/rule.svg" alt="" width="100%" />
</p>

### A little about me

Hey, I'm **Prashant**. I'm part of the team at **KITTY CORP**.

I like the part of technology where an idea stops being a conversation and starts becoming something real. This is where I'll share what I'm experimenting with, what I'm learning, and whatever I build along the way.

### What you'll find here

| **01 / Ideas** | **02 / Experiments** | **03 / Progress** |
| :--- | :--- | :--- |
| Concepts worth exploring. | Things I'm trying out and learning from. | Projects that grow a little better with each iteration. |

### Part of KITTY CORP

[**KITTY CORP ↗**](https://kittycorp.vercel.app/) is an independent technology startup working across AI, software, web and app development, cybersecurity, and experimental technology.

I'm part of the team, learning and contributing as we build.

### The work

The repositories on this profile are the best place to see the actual code and projects. I'm keeping this space focused on the work rather than a wall of badges.

<p align="center">
  <img src="./assets/rule.svg" alt="" width="100%" />
</p>

<p align="center">
  <a href="https://kittycorp.vercel.app/">Explore KITTY CORP ↗</a>
</p>

<p align="center">
  <img src="./assets/signoff.svg" alt="Keep building — Prashant, KITTY CORP" width="100%" />
</p>
